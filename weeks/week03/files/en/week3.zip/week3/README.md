# Week 3 terminal practice files

This archive is for the "Intro to the Terminal" practice. All the scores in it are made up.

- A.csv, B.csv, C.csv: quiz scores of classes A, B and C, 40 students each
- Columns: student_id (a made-up ID), score (0 to 100)

If you can see this file, you have already unpacked the parcel with cd, ls, mv and unzip.
